import { Component } from '@angular/core';
import { from } from 'rxjs';
import {AlbumServiceService} from './album-service.service'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  data:Array<any>
  totalRecords = String
  p: number = 1;
  constructor(private AlbumService: AlbumServiceService){
    this.data=new Array<any>()

  }
  getDataFromAPI() {
    this.AlbumService.getData().subscribe((data) =>{
     console.log(data)
     this.data = data
    //  this.totalRecords = data.results.length
    })
  }
}
